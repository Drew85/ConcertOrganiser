package com.codeccol.raven.concert.model;

public enum Style {
    ROCK,
    POP,
    JAZZ;
}
